-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1
-- Tiempo de generación: 23-10-2025 a las 02:12:35
-- Versión del servidor: 10.4.32-MariaDB
-- Versión de PHP: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `aerosoft`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `administradores`
--

CREATE TABLE `administradores` (
  `id_administrador` int(11) NOT NULL,
  `Nombres` varchar(50) NOT NULL,
  `Primer_Apellido` varchar(50) NOT NULL,
  `Segundo_Apellido` varchar(50) NOT NULL,
  `Fecha_Nacimiento` date NOT NULL,
  `id_genero` int(11) NOT NULL,
  `id_td` int(11) NOT NULL DEFAULT 1,
  `N_Documento` int(11) NOT NULL,
  `id_rol` int(11) NOT NULL DEFAULT 2,
  `Celular` varchar(10) NOT NULL,
  `Correo` varchar(250) NOT NULL,
  `Password` varchar(500) NOT NULL,
  `Activida` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `administradores`
--

INSERT INTO `administradores` (`id_administrador`, `Nombres`, `Primer_Apellido`, `Segundo_Apellido`, `Fecha_Nacimiento`, `id_genero`, `id_td`, `N_Documento`, `id_rol`, `Celular`, `Correo`, `Password`, `Activida`) VALUES
(1, 'Luis Fernando', 'Acosta', 'Vega', '2005-11-22', 1, 1, 1038105090, 1, '3134404667', 'leoescorp2552@gmail.com', '$2y$12$qwQ.eF/N.vca64Vl/foN9.PXfw.hO34nNSTaFwBhVsRS5DDOUoErC', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `asientos`
--

CREATE TABLE `asientos` (
  `id_asiento` int(11) NOT NULL,
  `Asiento` varchar(45) NOT NULL,
  `Disponibilidad` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `asientos`
--

INSERT INTO `asientos` (`id_asiento`, `Asiento`, `Disponibilidad`) VALUES
(1, '1A', 1),
(2, '1B', 1),
(3, '1C', 1),
(4, '2A', 1),
(5, '2B', 1),
(6, '2C', 1),
(7, '3A', 1),
(8, '3B', 1),
(9, '3C', 1),
(10, '4A', 1),
(11, '4B', 1),
(12, '4C', 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `busquedas`
--

CREATE TABLE `busquedas` (
  `id_busqueda` int(11) NOT NULL,
  `tipo_vuelo` tinyint(1) NOT NULL DEFAULT 1,
  `Origen` varchar(100) NOT NULL,
  `Destino` varchar(45) NOT NULL,
  `Fecha_ida` date DEFAULT NULL,
  `Fecha_ida_vuelta` date DEFAULT NULL,
  `Pasajeros` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `busquedas`
--

INSERT INTO `busquedas` (`id_busqueda`, `tipo_vuelo`, `Origen`, `Destino`, `Fecha_ida`, `Fecha_ida_vuelta`, `Pasajeros`) VALUES
(1, 1, 'Bogotá', 'Medellín', '2025-11-20', NULL, 1),
(2, 1, 'Cali', 'Cartagena', '2025-11-22', NULL, 1),
(3, 1, 'Bogotá', 'Barranquilla', '2025-11-25', NULL, 2);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `ciudades`
--

CREATE TABLE `ciudades` (
  `id_ciudad` int(11) NOT NULL,
  `nombre` varchar(150) NOT NULL,
  `codigo` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `ciudades`
--

INSERT INTO `ciudades` (`id_ciudad`, `nombre`, `codigo`) VALUES
(1, 'Bogotá', 'BOG'),
(2, 'Medellín', 'MDE'),
(3, 'Cali', 'CLO'),
(4, 'Cartagena', 'CTG'),
(5, 'Barranquilla', 'BAQ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `compras`
--

CREATE TABLE `compras` (
  `id_compra` int(11) NOT NULL,
  `id_reserva` int(11) NOT NULL,
  `id_metodo_pago` int(11) NOT NULL,
  `Tarjeta` varchar(50) NOT NULL,
  `Monto_Total` decimal(12,2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `compras`
--

INSERT INTO `compras` (`id_compra`, `id_reserva`, `id_metodo_pago`, `Tarjeta`, `Monto_Total`) VALUES
(1, 1, 1, '**** **** **** 1234', 280000.00);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `documentos`
--

CREATE TABLE `documentos` (
  `id_td` int(11) NOT NULL,
  `Documento` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `documentos`
--

INSERT INTO `documentos` (`id_td`, `Documento`) VALUES
(1, 'Cédula de ciudadanía'),
(2, 'Tarjeta de identidad ');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `facturas`
--

CREATE TABLE `facturas` (
  `id_factura` int(11) NOT NULL,
  `id_compra` int(11) NOT NULL,
  `codigo` varchar(45) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `facturas`
--

INSERT INTO `facturas` (`id_factura`, `id_compra`, `codigo`) VALUES
(1, 1, 'FAC-0001');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `generos`
--

CREATE TABLE `generos` (
  `id_genero` int(11) NOT NULL,
  `Genero` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `generos`
--

INSERT INTO `generos` (`id_genero`, `Genero`) VALUES
(1, 'Hombre'),
(2, 'Mujer'),
(3, 'Otro');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `metodo_pago`
--

CREATE TABLE `metodo_pago` (
  `id_metodo_pago` int(11) NOT NULL,
  `metodo_pago` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `metodo_pago`
--

INSERT INTO `metodo_pago` (`id_metodo_pago`, `metodo_pago`) VALUES
(1, 'Tarjeta de crédito'),
(2, 'Tarjeta débito'),
(3, 'Efectivo');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `reservas`
--

CREATE TABLE `reservas` (
  `id_reserva` int(11) NOT NULL,
  `id_vuelo` int(11) DEFAULT NULL,
  `id_asiento` int(11) DEFAULT NULL,
  `Precio_Final` decimal(12,2) DEFAULT NULL,
  `Nombres_Cliente` varchar(50) NOT NULL,
  `Primer_Apellido_Cliente` varchar(50) NOT NULL,
  `Segundo_Apellido_Cliente` varchar(50) NOT NULL,
  `Fecha_Nacimiento` date NOT NULL,
  `id_genero` int(11) NOT NULL,
  `id_td` int(11) NOT NULL,
  `N_Documento` varchar(20) DEFAULT NULL,
  `Celular` varchar(15) DEFAULT NULL,
  `Correo` varchar(250) NOT NULL,
  `Acompañante` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `reservas`
--

INSERT INTO `reservas` (`id_reserva`, `id_vuelo`, `id_asiento`, `Precio_Final`, `Nombres_Cliente`, `Primer_Apellido_Cliente`, `Segundo_Apellido_Cliente`, `Fecha_Nacimiento`, `id_genero`, `id_td`, `N_Documento`, `Celular`, `Correo`, `Acompañante`) VALUES
(1, 1, 2, 280000.00, 'Carlos', 'Gómez', 'Rojas', '1995-05-15', 1, 1, '1012345678', '3201234567', 'carlos@gmail.com', 0),
(2, 1, 2, 0.00, 'luis fernando', 'Acosta', 'Vega', '2005-11-22', 1, 1, '1038105090', '3134404667', 'leoescorp2552@gmail.com', 0),
(3, 1, 3, 0.00, 'luis fernando', 'Acosta', 'Vega', '2005-11-22', 1, 1, '1038105090', '3134404667', 'leoescorp2552@gmail.com', 0),
(4, 1, 4, 0.00, 'luis fernando', 'Acosta', 'Vega', '2005-11-22', 1, 1, '1038105090', '3134404667', 'leoescorp2552@gmail.com', 0);

--
-- Disparadores `reservas`
--
DELIMITER $$
CREATE TRIGGER `trg_reserva_asiento` AFTER INSERT ON `reservas` FOR EACH ROW BEGIN
  UPDATE vuelo_asiento
  SET Disponible = 0
  WHERE id_vuelo = NEW.id_vuelo AND id_asiento = NEW.id_asiento;
END
$$
DELIMITER ;

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `roles`
--

CREATE TABLE `roles` (
  `id_rol` int(11) NOT NULL,
  `Rol` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `roles`
--

INSERT INTO `roles` (`id_rol`, `Rol`) VALUES
(1, 'Administrador'),
(2, 'Editor');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `sessions`
--

CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Volcado de datos para la tabla `sessions`
--

INSERT INTO `sessions` (`id`, `user_id`, `ip_address`, `user_agent`, `payload`, `last_activity`) VALUES
('MPuQKTneXsJYpH0cXwqZTPVFsJNhDfL5cBC2WoXn', NULL, '127.0.0.1', 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/141.0.0.0 Safari/537.36 Edg/141.0.0.0', 'YTo0OntzOjY6Il90b2tlbiI7czo0MDoiQzlxdUtMa0hIcXBmVzMwcXppUGZlR1Z4SjJCNmlvSUtvWkU0emJCOSI7czo2OiJfZmxhc2giO2E6Mjp7czozOiJvbGQiO2E6MDp7fXM6MzoibmV3IjthOjA6e319czo5OiJfcHJldmlvdXMiO2E6MTp7czozOiJ1cmwiO3M6NTA6Imh0dHA6Ly8xMjcuMC4wLjE6ODAwMC92dWVsb3MvMS9yZXNlcnZhcj9hc2llbnRvPTJCIjt9czozOiJ1cmwiO2E6MTp7czo4OiJpbnRlbmRlZCI7czozMzoiaHR0cDovLzEyNy4wLjAuMTo4MDAwL0FkbWluL0luZGV4Ijt9fQ==', 1761177804);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_avion`
--

CREATE TABLE `tipo_avion` (
  `id_tipo_avion` int(11) NOT NULL,
  `Tipo_Avion` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipo_avion`
--

INSERT INTO `tipo_avion` (`id_tipo_avion`, `Tipo_Avion`) VALUES
(1, 'Airbus A320'),
(2, 'Boeing 737'),
(3, 'Embraer 190');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipo_tiquete`
--

CREATE TABLE `tipo_tiquete` (
  `id_tipo_tiquete` int(11) NOT NULL,
  `tipo_tiquete` varchar(50) NOT NULL,
  `Porcentaje` decimal(5,2) NOT NULL,
  `Beneficios` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `tipo_tiquete`
--

INSERT INTO `tipo_tiquete` (`id_tipo_tiquete`, `tipo_tiquete`, `Porcentaje`, `Beneficios`) VALUES
(1, 'Básico', 0.00, 'Sin equipaje adicional'),
(2, 'Premium', 25.00, 'Equipaje + refrigerio'),
(3, 'VIP', 50.00, 'Equipaje, comida y asiento premium');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vuelos`
--

CREATE TABLE `vuelos` (
  `id_vuelo` int(11) NOT NULL,
  `id_busqueda` int(11) NOT NULL,
  `Origen` varchar(100) DEFAULT NULL,
  `Destino` varchar(100) DEFAULT NULL,
  `Fecha_Salida` date DEFAULT NULL,
  `Hora_Salida` time DEFAULT NULL,
  `Duracion` varchar(50) DEFAULT NULL,
  `Cupo` int(11) NOT NULL DEFAULT 0,
  `N_Avion` varchar(50) NOT NULL,
  `id_tipo_avion` int(11) NOT NULL,
  `Precio` decimal(12,2) NOT NULL,
  `id_tipo_tiquete` int(11) NOT NULL,
  `Estado` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vuelos`
--

INSERT INTO `vuelos` (`id_vuelo`, `id_busqueda`, `Origen`, `Destino`, `Fecha_Salida`, `Hora_Salida`, `Duracion`, `Cupo`, `N_Avion`, `id_tipo_avion`, `Precio`, `id_tipo_tiquete`, `Estado`) VALUES
(1, 1, 'Bogotá', 'Medellín', '2025-10-22', '08:30:00', '1h 10m', 12, 'AV123', 1, 280000.00, 1, 1),
(2, 2, 'Cali', 'Cartagena', '2025-11-22', '10:15:00', '1h 50m', 12, 'LA456', 2, 420000.00, 2, 1),
(3, 3, 'Bogotá', 'Barranquilla', '2025-11-25', '14:00:00', '1h 45m', 12, 'VE789', 3, 500000.00, 3, 1);

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `vuelo_asiento`
--

CREATE TABLE `vuelo_asiento` (
  `id_vuelo_asiento` int(11) NOT NULL,
  `id_vuelo` int(11) NOT NULL,
  `id_asiento` int(11) NOT NULL,
  `Disponible` tinyint(1) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Volcado de datos para la tabla `vuelo_asiento`
--

INSERT INTO `vuelo_asiento` (`id_vuelo_asiento`, `id_vuelo`, `id_asiento`, `Disponible`) VALUES
(1, 1, 1, 0),
(2, 1, 2, 0),
(3, 1, 3, 0),
(4, 1, 4, 0),
(5, 1, 5, 1),
(6, 1, 6, 1),
(7, 1, 7, 1),
(8, 1, 8, 1),
(9, 1, 9, 1),
(10, 1, 10, 1),
(11, 1, 11, 1),
(12, 1, 12, 1),
(16, 2, 1, 1),
(17, 2, 2, 1),
(18, 2, 3, 1),
(19, 2, 4, 1),
(20, 2, 5, 1),
(21, 2, 6, 1),
(22, 2, 7, 1),
(23, 2, 8, 1),
(24, 2, 9, 1),
(25, 2, 10, 1),
(26, 2, 11, 1),
(27, 2, 12, 1),
(31, 3, 1, 1),
(32, 3, 2, 1),
(33, 3, 3, 1),
(34, 3, 4, 1),
(35, 3, 5, 1),
(36, 3, 6, 1),
(37, 3, 7, 1),
(38, 3, 8, 1),
(39, 3, 9, 1),
(40, 3, 10, 1),
(41, 3, 11, 1),
(42, 3, 12, 1);

--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `administradores`
--
ALTER TABLE `administradores`
  ADD PRIMARY KEY (`id_administrador`),
  ADD UNIQUE KEY `idadministradores_UNIQUE` (`id_administrador`),
  ADD KEY `fk_administrador_genero_idx` (`id_genero`),
  ADD KEY `fk_administrador_td_idx` (`id_td`),
  ADD KEY `fk_administradores_rol_idx` (`id_rol`);

--
-- Indices de la tabla `asientos`
--
ALTER TABLE `asientos`
  ADD PRIMARY KEY (`id_asiento`),
  ADD UNIQUE KEY `id_asiento_UNIQUE` (`id_asiento`);

--
-- Indices de la tabla `busquedas`
--
ALTER TABLE `busquedas`
  ADD PRIMARY KEY (`id_busqueda`),
  ADD UNIQUE KEY `id_busqueda_UNIQUE` (`id_busqueda`);

--
-- Indices de la tabla `ciudades`
--
ALTER TABLE `ciudades`
  ADD PRIMARY KEY (`id_ciudad`);

--
-- Indices de la tabla `compras`
--
ALTER TABLE `compras`
  ADD PRIMARY KEY (`id_compra`),
  ADD UNIQUE KEY `id_compra_UNIQUE` (`id_compra`),
  ADD KEY `fk_compra_reserva_idx` (`id_reserva`),
  ADD KEY `fk:compra_metodo_pago_idx` (`id_metodo_pago`);

--
-- Indices de la tabla `documentos`
--
ALTER TABLE `documentos`
  ADD PRIMARY KEY (`id_td`),
  ADD UNIQUE KEY `id_td_UNIQUE` (`id_td`);

--
-- Indices de la tabla `facturas`
--
ALTER TABLE `facturas`
  ADD PRIMARY KEY (`id_factura`),
  ADD UNIQUE KEY `id_factura_UNIQUE` (`id_factura`),
  ADD KEY `fk_factura_compra_idx` (`id_compra`);

--
-- Indices de la tabla `generos`
--
ALTER TABLE `generos`
  ADD PRIMARY KEY (`id_genero`),
  ADD UNIQUE KEY `id_genero_UNIQUE` (`id_genero`);

--
-- Indices de la tabla `metodo_pago`
--
ALTER TABLE `metodo_pago`
  ADD PRIMARY KEY (`id_metodo_pago`),
  ADD UNIQUE KEY `id_metodo_pago_UNIQUE` (`id_metodo_pago`);

--
-- Indices de la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD PRIMARY KEY (`id_reserva`),
  ADD UNIQUE KEY `id_reserva_UNIQUE` (`id_reserva`),
  ADD UNIQUE KEY `ux_vuelo_asiento_cliente` (`id_vuelo`,`id_asiento`,`N_Documento`),
  ADD KEY `fk_reserva_genero_idx` (`id_genero`),
  ADD KEY `fk_reserva_td_idx` (`id_td`),
  ADD KEY `fk_reserva_asiento` (`id_asiento`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`id_rol`),
  ADD UNIQUE KEY `idroles_UNIQUE` (`id_rol`);

--
-- Indices de la tabla `sessions`
--
ALTER TABLE `sessions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sessions_user_id_index` (`user_id`),
  ADD KEY `sessions_last_activity_index` (`last_activity`);

--
-- Indices de la tabla `tipo_avion`
--
ALTER TABLE `tipo_avion`
  ADD PRIMARY KEY (`id_tipo_avion`),
  ADD UNIQUE KEY `id_tipo_avion_UNIQUE` (`id_tipo_avion`);

--
-- Indices de la tabla `tipo_tiquete`
--
ALTER TABLE `tipo_tiquete`
  ADD PRIMARY KEY (`id_tipo_tiquete`),
  ADD UNIQUE KEY `id_tipo_tiquete_UNIQUE` (`id_tipo_tiquete`);

--
-- Indices de la tabla `vuelos`
--
ALTER TABLE `vuelos`
  ADD PRIMARY KEY (`id_vuelo`),
  ADD UNIQUE KEY `id_vuelo_UNIQUE` (`id_vuelo`),
  ADD KEY `fk_vuelo_busqueda_idx` (`id_busqueda`),
  ADD KEY `fk_vuelo_tipo_avion_idx` (`id_tipo_avion`),
  ADD KEY `fk_vuelo_tipo_tiquete_idx` (`id_tipo_tiquete`);

--
-- Indices de la tabla `vuelo_asiento`
--
ALTER TABLE `vuelo_asiento`
  ADD PRIMARY KEY (`id_vuelo_asiento`),
  ADD UNIQUE KEY `ux_vuelo_asiento` (`id_vuelo`,`id_asiento`),
  ADD KEY `fk_va_asiento` (`id_asiento`),
  ADD KEY `idx_vuelo_asiento` (`id_vuelo`,`Disponible`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `administradores`
--
ALTER TABLE `administradores`
  MODIFY `id_administrador` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `asientos`
--
ALTER TABLE `asientos`
  MODIFY `id_asiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT de la tabla `busquedas`
--
ALTER TABLE `busquedas`
  MODIFY `id_busqueda` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `ciudades`
--
ALTER TABLE `ciudades`
  MODIFY `id_ciudad` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT de la tabla `compras`
--
ALTER TABLE `compras`
  MODIFY `id_compra` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `documentos`
--
ALTER TABLE `documentos`
  MODIFY `id_td` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `facturas`
--
ALTER TABLE `facturas`
  MODIFY `id_factura` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT de la tabla `generos`
--
ALTER TABLE `generos`
  MODIFY `id_genero` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `metodo_pago`
--
ALTER TABLE `metodo_pago`
  MODIFY `id_metodo_pago` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `reservas`
--
ALTER TABLE `reservas`
  MODIFY `id_reserva` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `id_rol` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `tipo_avion`
--
ALTER TABLE `tipo_avion`
  MODIFY `id_tipo_avion` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `tipo_tiquete`
--
ALTER TABLE `tipo_tiquete`
  MODIFY `id_tipo_tiquete` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `vuelos`
--
ALTER TABLE `vuelos`
  MODIFY `id_vuelo` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `vuelo_asiento`
--
ALTER TABLE `vuelo_asiento`
  MODIFY `id_vuelo_asiento` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `administradores`
--
ALTER TABLE `administradores`
  ADD CONSTRAINT `fk_administrador_genero` FOREIGN KEY (`id_genero`) REFERENCES `generos` (`id_genero`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_administrador_td` FOREIGN KEY (`id_td`) REFERENCES `documentos` (`id_td`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_administradores_rol` FOREIGN KEY (`id_rol`) REFERENCES `roles` (`id_rol`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `compras`
--
ALTER TABLE `compras`
  ADD CONSTRAINT `fk:compra_metodo_pago` FOREIGN KEY (`id_metodo_pago`) REFERENCES `metodo_pago` (`id_metodo_pago`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_compra_reserva` FOREIGN KEY (`id_reserva`) REFERENCES `reservas` (`id_reserva`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `facturas`
--
ALTER TABLE `facturas`
  ADD CONSTRAINT `fk_factura_compra` FOREIGN KEY (`id_compra`) REFERENCES `compras` (`id_compra`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `reservas`
--
ALTER TABLE `reservas`
  ADD CONSTRAINT `fk_reserva_asiento` FOREIGN KEY (`id_asiento`) REFERENCES `asientos` (`id_asiento`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_reserva_genero` FOREIGN KEY (`id_genero`) REFERENCES `generos` (`id_genero`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_reserva_td` FOREIGN KEY (`id_td`) REFERENCES `documentos` (`id_td`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_reserva_vuelo` FOREIGN KEY (`id_vuelo`) REFERENCES `vuelos` (`id_vuelo`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `vuelos`
--
ALTER TABLE `vuelos`
  ADD CONSTRAINT `fk_vuelo_busqueda` FOREIGN KEY (`id_busqueda`) REFERENCES `busquedas` (`id_busqueda`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_vuelo_tipo_avion` FOREIGN KEY (`id_tipo_avion`) REFERENCES `tipo_avion` (`id_tipo_avion`) ON DELETE NO ACTION ON UPDATE NO ACTION,
  ADD CONSTRAINT `fk_vuelo_tipo_tiquete` FOREIGN KEY (`id_tipo_tiquete`) REFERENCES `tipo_tiquete` (`id_tipo_tiquete`) ON DELETE NO ACTION ON UPDATE NO ACTION;

--
-- Filtros para la tabla `vuelo_asiento`
--
ALTER TABLE `vuelo_asiento`
  ADD CONSTRAINT `fk_va_asiento` FOREIGN KEY (`id_asiento`) REFERENCES `asientos` (`id_asiento`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_va_vuelo` FOREIGN KEY (`id_vuelo`) REFERENCES `vuelos` (`id_vuelo`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
